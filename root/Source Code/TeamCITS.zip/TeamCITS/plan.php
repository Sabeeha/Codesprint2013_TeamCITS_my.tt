<!DOCTYPE html>
<html lang="en">
<head>
<title>Plan | my.TT</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>  
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>

<!-- Ratings Jquery -->
<link rel='stylesheet' href='js/rating/jquery.rating.css'>
<script src="js/rating/jquery.form.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.MetaData.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.rating.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.rating.pack.js" type="text/javascript" charset="utf-8"></script>
<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "ur-2a253e3d-c198-9b8d-5f3-c893612cced1", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body id="page1">
<?php include 'fb_script.php';?>
<div class="extra">
	<div class="main">
<!-- header -->
		<header>
			<?php include 'fb_like.php';?>	
			<nav>
				<?php include 'menu.php';?>
			</nav>
			<article class="col1">
				<ul class="tabs">
					<li><a href="#" class="active">Flight</a></li>
					
				</ul>
				<div class="tabs_cont">
					<form id="form_1" action="" method="post">
						<div class="bg">
							<div class="wrapper">
								<div class="radio">
									<input type="radio" name="name1" checked>Round trip
								</div>
								<div class="radio"><input type="radio" name="name1">One way</div>
							</div>
							<a href="#">Multiple destinations</a>
							<div class="wrapper"><input type="text" class="input">From</div>
							<div class="wrapper"><input type="text" class="input">To</div>	
							<div class="wrapper check_box"><input type="checkbox" checked ><a href="#">Search nearby airports</a></div>	
							<div class="wrapper"><input type="text" class="input input2" value="04/11/2010"  onblur="if(this.value=='') this.value='04/11/2010'" onfocus="if(this.value =='04/11/2010' ) this.value=''">Depart (mm/dd/yy)</div>
							<div class="wrapper pad_bot1"><input type="text" class="input input2" value="04/11/2010"  onblur="if(this.value=='') this.value='04/11/2010'" onfocus="if(this.value =='04/11/2010' ) this.value=''">Return  (mm/dd/yy)</div>
							<div class="wrapper">
								<div class="radio"><input type="radio" name="name2" checked>Economy cabin</div>
								<div class="radio end"><input type="radio" name="name2">Business</div>
							</div>
							<div class="wrapper pad_bot1">
								<a href="#" class="button" onclick="document.getElementById('form_1').submit()">Search</a>
								Audlts <select><option>1</option></select>
							</div>
						</div>							
					</form>
				</div>
				<div class="tabs_cont">
					<form id="form_1" action="" method="post">
						<div class="bg">
							<div class="wrapper">
								<div class="radio">
									<input type="radio" name="name1" checked>Round trip
								</div>
								<div class="radio"><input type="radio" name="name1">One way</div>
							</div>
							<a href="#">Multiple destinations</a>
							<div class="wrapper"><input type="text" class="input">From</div>
							<div class="wrapper"><input type="text" class="input">To</div>	
							<div class="wrapper check_box"><input type="checkbox" checked ><a href="#">Search nearby airports</a></div>	
							<div class="wrapper"><input type="text" class="input input2" value="04/11/2010"  onblur="if(this.value=='') this.value='04/11/2010'" onfocus="if(this.value =='04/11/2010' ) this.value=''">Depart (mm/dd/yy)</div>
							<div class="wrapper pad_bot1"><input type="text" class="input input2" value="04/11/2010"  onblur="if(this.value=='') this.value='04/11/2010'" onfocus="if(this.value =='04/11/2010' ) this.value=''">Return  (mm/dd/yy)</div>
							<div class="wrapper">
								<div class="radio"><input type="radio" name="name2" checked>Economy cabin</div>
								<div class="radio end"><input type="radio" name="name2">Business</div>
							</div>
							<div class="wrapper pad_bot1">
								<a href="#" class="button" onclick="document.getElementById('form_1').submit()">Search</a>
								Audlts <select><option>1</option></select>
							</div>
						</div>							
					</form>
				</div>
			</article>
			<article class="col1 pad_left1">
				<div class="text">
					
					<h2>Plan Your Trip </h2>
					<p> Currently under development!</p>
					<p> Planning your trip? Book using our partner airline for great deals, super savings and other unbeatable discounts!</p>
					<p> Need help choosing or making reservations? Contact a local travel agent.</p>
					<div class="img"><img src="images/under_construction.png" alt=""></div>
				</div>
		</header>
<!-- / header -->
<!-- content -->
		<section id="content">
			<article class="col1">
				<h3>Hot Picks</h3>
				<div class="pad">
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/carn1.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Carnival 2K14</strong></p>
						<p class="pad_bot2">Come and join us for "the greatest show on earth" <a href="#" class="marker_1"></a></p>
						
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/tob1.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Travel Tobago</strong></p>
						<p class="pad_bot2">Plan your vacation to our "island paradise" <a href="#" class="marker_1"></a></p>
						
					</div>
					
				</div>
       		</article>
			
			<article class="col2 pad_left1">
				<h2>Contact a Local Travel Agent</h2>
				<?php include "01/query_travel.php" ?>
				<!-- <div class="wrapper under">
					<figure class="left marg_right1"><img src="images/page1_img4.jpg" alt=""></figure>
					<p class="pad_bot2"><strong>Hotel du Havre</strong></p>
					<p class="pad_bot2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
					<p class="pad_bot2"><strong>Nemo enim ipsam voluptatem</strong> quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.</p>
					<a href="#" class="marker_2"></a>
				</div>
				<div class="wrapper">
					<figure class="left marg_right1"><img src="images/page1_img5.jpg" alt=""></figure>
					<p class="pad_bot2"><strong>Hotel Vacance</strong></p>
					<p class="pad_bot2">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa.</p>
					<p class="pad_bot2">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda.</p>
					<a href="#" class="marker_2"></a>
				</div> -->
       		</article>
			
		</section>
<!-- / content -->
	</div>
	<div class="block"></div>
</div>
<?php include 'social.php';?>
<div class="body1">
	<div class="main">
<!-- footer -->
		<footer>
			<?php include 'footer.php';?>
		</footer>
<!-- / footer -->
	</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>