<!DOCTYPE html>
<html lang="en">
<head>
<title>Home | my.TT</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>  
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>

<script type="text/javascript" src="js/jquery.min.js.js"></script>
<script type="text/javascript" src="js/coin-slider.js"></script>
<link rel="stylesheet" href="css/coin-slider-styles.css" type="text/css" />
<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "ur-2a253e3d-c198-9b8d-5f3-c893612cced1", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body id="page1">
<?php include 'fb_script.php';?>

<div class="extra">
	<div class="main">
<!-- header -->
		<header>
		<?php include 'fb_like.php';?>	
			<nav>
				<?php include 'menu.php';?>
			</nav>
			<article class="col1">
				<script language="JavaScript" type="text/javascript"> 
 document.write('<script language="JavaScript" src="http://www.worldweatheronline.com/widget/v2/weather-widget.ashx?locid=2468815&root_id=2468586&wc=LOCAL_WEATHER&map=~/guamal-weather-widget/saint-george/tt.aspx&width=230&custom_header=Trinidad And Tobago Weather&num_of_day=3&title_bg_color=F24350&title_text_color=FFFFFF&widget_bg_color=424242&widget_text_color=FFFFFF&type=js&cb=' + Math.random() + '" type="text/javascript"><\/scr' + 'ipt>');
 </script><noscript><a href="http://www.worldweatheronline.com" alt="7 day Guamal Weather, Trinidad And Tobago weather">7 day Guamal Weather, Trinidad And Tobago weather</a> provided by <a href="http://www.worldweatheronline.com">World Weather Online</a></noscript>
			</article>
			
				<div id="games">
						<a href="experience.php" target="_blank">
							<img src="images/4.jpg" />
							<span>
								<b>Places of Interest</b><br />
								Explore hidden waterfalls and lush hiking trails.
							</span>
						</a>
						
						<a href="experience.php" target="_blank">
							<img src="images/5.jpg" alt="Beach1" />
							<span>
								<b>Hotels and Resorts</b><br />
								The International Waterfront
							</span>
						</a>
						
						<a href="experience.php" target="_blank">
							<img src="images/7.jpg" alt="" />
							<span>
								<b>Hotels and Resorts</b><br />
								The view from the north east peninsula
							</span>
						</a>
						
						<a href="experience.php" target="_blank">
							<img src="images/9.jpg" alt="" />
							<span>
								<b>Places of Interest</b><br />
								Breathtaking sunset in the West
							</span>
						</a>
					
						<a href="experience.php" target="_blank">
							<img src="images/10.jpg" alt="" />
							<span>
								<b>Beaches</b><br />
								White sandy beaches.
							</span>
						</a>
					
						
						<a href="experience.php" target="_blank">
							<img src="images/11.jpg" alt="" />
							<span>
								<b>Places of Interest</b><br />
								See our history
							</span>
						</a>
						
						<a href="experience.php" target="_blank">
							<img src="images/25.jpg" alt="" />
							<span>
								<b>Beaches</b><br />
								Hidden beaches
							</span>
						</a>
							
						<a href="experience.php" target="_blank">
							<img src="images/37.jpg" alt="" />
							<span>
								<b>Beaches</b><br />
								Serenity redefined.
							</span>
						</a>
						<a href="experience.php" target="_blank">
							<img src="images/38.jpg" alt="" />
							<span>
								<b>Nightclubs and Lounges</b><br />
								Nightlife like you've never seen before.
							</span>
						</a>
			
				</div>
		</header>
<!-- / header -->
<!-- content -->
		<section id="content">
			<article class="col1">
				<h3>Quick Tools</h3>
				<div class="pad">
					<div class="wrapper under">
						<!-- Currency Converter Script - FX-EXCHANGE.COM -->
<div style="width:228px;border:1px solid #424242;"><div style="text-align:left;background-color:#424242;width:100%;border-bottom:0px;height:16px; font-size:12px;font-weight:bold;padding:5px 0px;"> <span  style="background-image:url(http://s3.fx-exchange.com/fx.png); background-position: 0 -1264px; width:100%; height:15px; background-repeat:no-repeat;margin-left:5px;"><a href="http://ttd.fx-exchange.com/" target="_blank" style="color:#FFFFFF; text-decoration:none;padding-left:22px;">Trinidad and Tobago Dollar </a></span></div><script type="text/javascript" src="http://widget.fx-exchange.com/converter.php?fg=en&ff=TTD&ft=USD,EUR,GBP,JPY,CAD,AUD,VEF,&fa=1&cb=F0F0F0&fy=3"></script></div>
<!-- End of Currency Converter Script -->
						
					</div>
					<div class="wrapper under">
						<!-- Currency Converter Script - FX-EXCHANGE.COM -->
<div style="width:228px;border:1px solid #424242;"><div style="text-align:center;background-color:#424242;width:100%;font-size:13px;font-weight:bold;height:18px;padding-top:2px;"><a href="http://www.fx-exchange.com/" target="_blank" style="color:#FFFFFF;text-decoration:none;">Currency Converter</a></div><script type="text/javascript" src="http://widget.fx-exchange.com/converter.php?fg=en&ff=TTD&ft=USD&fa=100&cb=F0F0F0&fy=1"></script></div>
<!-- End of Currency Converter Script -->
						
					</div>
					<!-- CUT NG
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/page1_img3.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Cruise<br>Holidays</strong></p>
						<p class="pad_bot2">Lorem ipsum dolor sit amet, consect etuer adipiscing.</p>
						<a href="#" class="marker_1"></a>
					</div>
				</div>
				-->
       		</article>
			<article class="col2 pad_left1">
				<h2>Welcome to my.tt</h2>
				<div class="wrapper under">
					<figure class="left marg_right1"><img src="images/palm.jpg" alt=""></figure>
					<p class="pad_bot2"><strong>All the information you need</strong></p>
					<p class="pad_bot2">All the information on T&T that you need, right at your fingertips. Discover hidden gems on the island, tantalize your tastebuds with our incredibly diverse culinary offerings, seek out the hottest clubs or find that perfect spot to rest. </p>
					<p class="pad_bot2">Why my.tt? After your visit, you'll be a part of us.</p>
					<p class="pad_bot2">Learn more.</p>
					
					<a href="experience.php" class="marker_2"></a>
				</div>
				<!-- CUT NG
				<div class="wrapper">
					<figure class="left marg_right1"><img src="images/page1_img5.jpg" alt=""></figure>
					<p class="pad_bot2"><strong>Hotel Vacance</strong></p>
					<p class="pad_bot2">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa.</p>
					<p class="pad_bot2">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda.</p>
					<a href="#" class="marker_2"></a>
				</div>
				-->
       		</article>
		</section>
<!-- / content -->
	</div>
	<div class="block"></div>
</div>
<?php include 'social.php';?>
<div class="body1">
	<div class="main">
<!-- footer -->
		<footer>
			<?php include 'footer.php';?>
		</footer>
<!-- / footer -->
	</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script>
			$('#games').coinslider();
</script>
</body>
</html>