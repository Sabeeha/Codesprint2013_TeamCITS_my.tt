-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2013 at 04:16 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mytt`
--

-- --------------------------------------------------------

--
-- Table structure for table `business`
--

CREATE TABLE IF NOT EXISTS `business` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(80) DEFAULT NULL,
  `b_location` varchar(150) DEFAULT NULL,
  `b_contact` varchar(20) DEFAULT NULL,
  `b_category` varchar(50) DEFAULT NULL,
  `b_rank` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89 ;

--
-- Dumping data for table `business`
--

INSERT INTO `business` (`id`, `b_name`, `b_location`, `b_contact`, `b_category`, `b_rank`) VALUES
(1, 'Apsara Restaurant', 'Level 1, #13 Queens Park Savannah East, Port of Spain, Trinidad', '623-7659', 'Restaurant', 0),
(2, 'Flavours on the Avenue', '40 Ariapita Avenue, Woodbrook, Trinidad', '628-8687', 'Restaurant', 0),
(3, 'Lighthouse Restaurant', 'Point Gourde Chaguaramas Bay, Trinidad', '634-4384', 'Restaurant', 0),
(4, 'Tamnak Thai Restaurant', 'Level 2 #13 Queens Park Savannah East,Port of Spain, Trinidad', '625-9715', 'Restaurant', 0),
(5, 'Botticelli''s', 'Grand Bazaar, Valsayn, Trinidad', '663-8733', 'Restaurant', 0),
(6, 'Chelsea''s Seafood Ribs and Steakhouse', 'Valpark Shopping Plaza, Valsayn, Trinidad', '645-8800', 'Restaurant', 0),
(7, 'Jenny''s Wok and Steak House', '175 Cipero Road, San Fernando, Trinidad', '652-1807', 'Restaurant', 0),
(8, 'Kariwak Village (Restaurant)', 'Store Bay Local Road, Crown Point,Tobago', '639-8442', 'Restaurant', 0),
(9, 'Muscovado Restaurant', 'Sunrise Loop Road, Trincity, Trinidad', '640-9259', 'Restaurant', 0),
(10, 'Sails Restaurant', 'Chaguaramas,Trinidad', '634-1712', 'Restaurant', 0),
(11, 'Plantation House', 'Ariapita Avenue and Cornelio Street, Woodbrook, Trinidad', '628-5551', 'Hotels and Resorts', 0),
(12, 'Abercromby Inn', '101 Abercromby St, Port of Spain, Trinidad', '624-3858', 'Hotels and Resorts', 0),
(13, 'Cascadia Hotel', 'Ariapita Rd, St Anns, Trinidad', '623-4208', 'Hotels and Resorts', 0),
(14, 'Crews Inn Hotel & Yachting Centre', 'Point Gourde,˜Chaguaramas, Trinidad', '634-4384', 'Hotels and Resorts', 0),
(15, 'Hyatt Regency Trinidad˜', '1 Wrightson Rd, Port of Spain,Trinidad', '623-2222', 'Hotels and Resorts', 0),
(16, 'Hilton Trinidad & Conference Centre˜', 'Lady Young Rd, Port of Spain, Trinidad', '624-3211', 'Hotels and Resorts', 0),
(17, 'Grafton Beach Resort˜', 'Stonehaven Bay, Tobago', '639-0191', 'Hotels and Resorts', 0),
(18, 'Magdalena Grand Beach Resort˜', 'Tobago Plantations, Estate Lowlands, Tobago', '660-8500', 'Hotels and Resorts', 0),
(19, 'Crown Point Beach Hotel Limited', 'Storebay Local Rd, Tobago', '639-8781', 'Hotels and Resorts', 0),
(20, 'Holiday Inn Express Hotel & Suites˜', '1 Exposition Dr,Trincity, Trinidad', '669-6209', 'Hotels and Resorts', 0),
(21, 'Hotel Carries On the Bay˜', 'Eastern Main Rd, Manzanilla, Trinidad', '668-5711', 'Hotels and Resorts', 0),
(22, 'Zen', '9-11 Keate St, Port of Spain, Trinidad', '624-8201', 'Night Clubs and Lounges', 0),
(23, '51 Degrees Lounge & Conference Centre', '51 Cipriani Blvd, Port of Spain, Trinidad', '627-0051', 'Night Clubs and Lounges', 0),
(24, 'THE RIG Restaurant and Lounge', 'South Trunk Rd La Romain', '687-6992', 'Night Clubs and Lounges', 0),
(25, 'Nuvo Sera', 'Port of Spain,Trinidad', NULL, 'Night Clubs and Lounges', 0),
(26, 'MovieTowne Entertainment & Shopping Complex', 'Audrey Jeffers Highway, Port of Spain, Trinidad', '627-8277', 'Movie Theatres', 0),
(27, 'Digicel Imax', 'One Woodbrook Place, Port of Spain, Trinidad', '299-4629', 'Movie Theatres', 0),
(28, 'Caribbean Cinemas (Trincity 8)', 'Trincity Mall, Trincity,Trinidad', '640-8788', 'Movie Theatres', 0),
(29, 'MovieTowne Entertainment & Shopping Complex', 'Price Plaza, Chaguanas, Trinidad', NULL, 'Movie Theatres', 0),
(30, 'MovieTowne Tobago', 'Gulf City Mall, Tobago', '627-8277', 'Movie Theatres', 0),
(31, 'Maracas Bay', 'North Coast,Trinidad', NULL, 'Beaches', 0),
(32, 'Tyrico', 'East of Maracas Bay', NULL, 'Beaches', 0),
(33, 'Manzanilla', 'North- East Coast, Trinidad', NULL, 'Beaches', 0),
(34, 'Mayaro', 'North- East Coast, Trinidad', NULL, 'Beaches', 0),
(35, 'Quinam Beach', 'South Coast. Access by the Coora Road and the Penal-Quinam Road, Trinidad', NULL, 'Beaches', 0),
(36, 'Las Cuevas', 'East of Tyrico', NULL, 'Beaches', 0),
(37, 'Salybia Bay', 'North- East Coast, Trinidad', NULL, 'Beaches', 0),
(38, 'Castara Beach', 'Located along North Side Road, Tobago', NULL, 'Beaches', 0),
(39, 'Englishman''s Bay', 'Located along North Side Road past Castara Bay', NULL, 'Beaches', 0),
(40, 'King''s Bay', 'Located along the Windward Road,Tobago', NULL, 'Beaches', 0),
(41, 'Man ''O War Bay', 'On the Windward Road, Tobago', NULL, 'Beaches', 0),
(42, 'Mount Irvine', 'Mount Irvine', NULL, 'Beaches', 0),
(43, 'Pigeon Point', 'Located on the leeward side of Tobago', NULL, 'Beaches', 0),
(44, 'Speyside Beach', 'Follow the Windward Road past King''s Bay', NULL, 'Beaches', 0),
(45, 'Store Bay', 'Crown Point', NULL, 'Beaches', 0),
(46, 'Turtle Beach', 'Located at the Great Courland Bay', NULL, 'Beaches', 0),
(47, 'Price Plaza', 'Endeavour Rd, Chaguanas,Trinidad', '675-5052', 'Shopping', 0),
(48, 'Shoppes Of Maraval', '3 Saddle Rd, Maraval, Trinidad', '628-0806', 'Shopping', 0),
(49, 'The Falls of West Mall', 'Western Mn Rd, West Moorings, Trinidad', '637-6255', 'Shopping', 0),
(50, 'Grand Bazaar Ltd', 'Uriah Butler & Churchill Roosevelt Hwy, Valsayn, Trinidad', '662-2282', 'Shopping', 0),
(51, 'Gulf City Ltd', 'Gulf City Shopping Complex, La Romain,Trinidad', '657-9251', 'Shopping', 0),
(52, 'Trincity Mall', 'Trincity,Trinidad', NULL, 'Shopping', 0),
(53, 'Gulf City Mall', 'Tobago', NULL, 'Shopping', 0),
(54, 'National Museum and Art Gallery', 'South-east corner of the Queen''s Park Savannah, Port of Spain, Trinidad', NULL, 'Places of Interest', 0),
(55, 'Chaguaramas Military History and Aviation Museum', 'Chaguaramas,Trinidad', NULL, 'Places of Interest', 0),
(56, 'Fort George', 'Port of Spain,Trinidad', NULL, 'Places of Interest', 0),
(57, 'Mount St. Benedict', 'St. Augustine, Trinidad', NULL, 'Places of Interest', 0),
(58, 'Kimme''s Sculpture Museum', 'Bethel, Mount Irvine, Tobago', NULL, 'Places of Interest', 0),
(59, 'The Art Gallery', 'Allfield''s Trace', NULL, 'Places of Interest', 0),
(60, 'Fort Bennett', 'Black Rock,Tobago', NULL, 'Places of Interest', 0),
(61, 'San Fernando Hill', 'San Fernando', NULL, 'Places of Interest', 0),
(62, 'Devil''s Woodyard', 'New Grant, Prices Town', NULL, 'Places of Interest', 0),
(63, 'Nariva Swamp', 'Nariva', NULL, 'Places of Interest', 0),
(64, 'Pointe-a-Pierre Wildfowl Trust', 'Pointe-a-Pierre', NULL, 'Places of Interest', 0),
(65, 'Knolly''s Tunnel', 'Tabaquite', NULL, 'Places of Interest', 0),
(66, 'Fort Granby', 'Granby Point', NULL, 'Places of Interest', 0),
(67, 'Crusoe''s Cave', 'Crown Point and Store Bay area', NULL, 'Places of Interest', 0),
(68, 'Little Tobago Island', 'Offshore of Speyside', NULL, 'Places of Interest', 0),
(69, 'Kalloo''s Auto Rentals Taxi Service & Tours', 'Piarco International Airport, Piarco, Trinidad', '669-5673', 'Move', 0),
(70, 'Econo-Car Rentals Ltd', '191-193 Western Main Rd, Trinidad', '622-8074', 'Move', 0),
(71, 'Yellow Cab Services Ltd', '1 College Rd, St.Augustine, Trinidad', '645-8294', 'Move', 0),
(72, 'A-1 Auto Rentals & Taxi Service', '66 Churchill Roosevelt Hwy San Juan, Trinidad', '638-8125', 'Move', 0),
(73, 'Camel Transport Services', '51 Pt Fortin Main Rd, Pt Fortin, Trinidad', '648-6438', 'Move', 0),
(74, 'Peter Gremli''s Car Rental & Transport Service', 'Crown Pt, Tobago', '639-8400', 'Move', 0),
(75, 'Quashie''s Rentals', 'Crown Pt Int''l Airport, Crown Pt, Tobago', '639-8397', 'Move', 0),
(76, 'Platimum Sponsor 1', 'Port-of-Spain', '636-00000', 'Restaurant', 10),
(77, 'Gold Sponsor 1', 'San Fernando', '665-0000', 'Restaurant', 8),
(78, 'Silver Sponsor 1', 'Couva', '679-0000', 'Restaurant', 6),
(79, 'Platinum Sponsor 1', 'Couva', '679-0000', 'Hotels and Resorts', 10),
(80, 'Gold Sponsor 1', 'Toco', '623-0000', 'Hotels and Resorts', 8),
(81, 'Silver Sponsor 1', 'Mayaro', '658-0000', 'Hotels and Resorts', 6),
(82, 'Silver Sponsor 1', 'Port-of-Spain', '658-0000', 'Night Clubs and Lounges', 6),
(83, 'Gold Sponsor 1', 'Port-of-Spain', '658-0210', 'Night Clubs and Lounges', 8),
(84, 'Platinum Sponsor 1', 'Tunapuna', '628-1220', 'Night Clubs and Lounges', 10),
(85, 'A Willoughby''s Travel Service', '90 Independence Sq, Port of Spain', '652-7747', 'Travel Agent', 0),
(86, 'Citi Tours & Travel Service', '143A Coffee St, San Fernando', '652-6993', 'Travel Agent', 0),
(87, 'Royal Travel & Tours ', '13 Blvd Bamboo Sett Valsayn', '663-9694', 'Travel Agent', 0),
(88, 'Platinum Sponsor ', 'Chaguanas', '665-9989', 'Travel Agent', 10);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(10) NOT NULL,
  `b_id` int(10) NOT NULL,
  `total_votes` int(5) NOT NULL DEFAULT '0',
  `total_value` int(5) NOT NULL DEFAULT '0',
  `used_ips` longtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `b_id`, `total_votes`, `total_value`, `used_ips`, `date`) VALUES
(1, 0, 0, 0, '', '2013-04-10 04:00:00'),
(2, 0, 0, 0, '', '2013-04-10 04:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
