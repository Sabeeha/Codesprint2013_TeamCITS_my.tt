			<article class="col1">
				<h3>Explore</h3>
				<div class="pad">
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/rest1.jpg" alt=""></figure> 
						<p class="pad_bot2"><a href="restaurants.php"><strong>Restaurants</strong></a></p>
							<p class="pad_bot2">Local, Regional and International Cuisines</p>
							<a href="restaurants.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/hotel.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="hotels.php"><strong>Hotels and Resorts</strong></a></p>
						<p class="pad_bot2">Find that perfect place to stay.</p>
						<a href="hotels.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/club.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="clubs.php"><strong>Night Clubs and lounges</strong></a></p>
						<p class="pad_bot2">Vibrant night life starts here.</p>
						<a href="clubs.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/movies.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="cinema.php"><strong>Movie Theatres</strong></a></p>
						<p class="pad_bot2">Catch the latest movies.</p>
						<a href="cinema.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/beach2.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="beaches.php"><strong>Beaches</strong></a></p>
						<p class="pad_bot2">Sun, sea and sand.</p>
						<a href="beaches.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/mall.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="shopping.php"><strong>Shopping</strong></a></p>
						<p class="pad_bot2">From souveniers to latest fashion trends.</p>
						<a href="shopping.php" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/taxi2.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="transport.php"><strong>Transport</strong></a></p>
						<p class="pad_bot2">Need a ride? From rentals to taxi services.</p>
						<a href="transport.php" class="marker_1"></a>
					</div>
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/placesofinterest.jpg" alt=""></figure>
						<p class="pad_bot2"><a href="places_interest.php"><strong>Places of Interest</strong></a></p>
						<p class="pad_bot2">Discover our vibrant history and culture.</p>
						<a href="places_interest.php" class="marker_1"></a>
					</div>
				</div>
       		</article>