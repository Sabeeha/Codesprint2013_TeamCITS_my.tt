<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'access';
$rec_limit = 10;
$_PHP_SELF = $_SERVER["PHP_SELF"];
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
mysql_select_db('mytt');
/* Get total number of records */
$sql = "select b_name,b_location,b_contact from  business where b_category='Beaches'";
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
$row = mysql_fetch_array($retval, MYSQL_NUM );
$rec_count = $row[0];
if( isset($_GET{'page'} ) )
{
   $page = $_GET{'page'} + 1;
   $offset = $rec_limit * $page ;
}
else
{
   $page = 0;
   $offset = 0;
}
$left_rec = $rec_count - ($page * $rec_limit);
$sql = "select b_name,b_location,b_contact from  business where b_category='Beaches' order by b_rank desc,b_name asc ".
       "LIMIT $offset, $rec_limit";
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
    echo "<b>{$row['b_name']} </b> <br> ".
         "Location : {$row['b_location']} <br> ".
         " <i>Contact : {$row['b_contact']} </i><br> ".
         "<br>".
		 "<form id='rating{$row['b_name']}'>
		    <input name='star1' type='radio' class='star' value = 1 />
			<input name='star1' type='radio' class='star' value = 2 />
			<input name='star1' type='radio' class='star' value = 3 />
			<input name='star1' type='radio' class='star' value = 4 />
			<input name='star1' type='radio' class='star' value = 5 /></form>".
         "<br> <br> <br> <br>";
} 
if( $page > 0 )
{
   $last = $page - 2;
   echo "<a href=\"$_PHP_SELF?page=$last\">Last 10 Records</a> |";
   echo "<a href=\"$_PHP_SELF?page=$page\">Next 10 Records</a>";
}
else if( $page == 0 )
{
   echo "<a href=\"$_PHP_SELF?page=$page\">Next 10 Records</a>";
}
else if( $left_rec < $rec_limit )
{
   $last = $page - 2;
   echo "<a href=\"$_PHP_SELF?page=$last\">Last 10 Records</a>";
}
mysql_close($conn);
?>