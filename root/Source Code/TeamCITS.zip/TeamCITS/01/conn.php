<?php
	$con = mysql_connect("localhost","root","access");
	if (!$con){
		die("Database connection failed: ".mysql_error());
	}

	$db_select = mysql_select_db("mytt",$con);
		if (!$db_select){
			die("Database selection failed:".mysql_error());
		}
?>