
<div class="wrapper">
				<h1><a href="index.php" id="logo">my.TT</a></h1>
				<div class="right">
					<div class="wrapper">
					
						<form id="search" action="" method="post">
							<div class="bg">
								 <input type="submit" class="submit" value="">
								<input id="myBox"type="text" class="input" /> 
								<script>
  // Input field and default text
  var $element = $('#myBox');
  var defaultText = 'Search my.tt';

  $element.focus(function(){
    // Focused
    $element.removeClass('defocused').addClass('focused');
    if($element.val() == defaultText)
      $element.val('');
  }).blur(function(){
    // Defocused
    $element.removeClass('focused').addClass('defocused');
    if($element.val() == '')
      $element.val(defaultText);
  });

  // Initialization
  $element.blur();
</script>
							</div> 
						</form> 
						<br><br><br>
						
					</div>
					
					<div class="wrapper">
						<nav>
						<ul id="top_nav">
							<div class="fb-like" data-href="https://www.facebook.com/pages/mytt/433779253379951" data-send="false" data-layout="button_count" data-width="20" data-show-faces="true"></div>
							</ul>
						</nav>
					</div>	
				</div>
			</div>