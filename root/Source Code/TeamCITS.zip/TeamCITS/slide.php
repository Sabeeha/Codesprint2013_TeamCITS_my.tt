<div id="games">
						<a href="#" target="_blank">
							<img src="images/38.jpg" alt="Night View" />
							<span>
								<b>Night View</b><br />
								Place some description here
							</span>
						</a>
						
						<a href="#" target="_blank">
							<img src="images/10.jpg" alt="Aerial Beach View" />
							<span>
								<b>Beach</b><br />
								Place some description here
							</span>
						</a>
						
						<a href="#" target="_blank">
							<img src="images/9.jpg" alt="Sunset" />
							<span>
								<b>Sunset</b><br />
								Place some description here
							</span>
						</a>
						
						<a href="#" target="_blank">
							<img src="images/21.jpg" alt="Brink" />
							<span>
								<b>View</b><br />
								Place some description here
							</span>
						</a>
					
						<a href="#" target="_blank" >
							<img src="images/36.jpg" alt="Waterfall" />
							<span>
								<b>Waterfall</b><br />
								Place some description here
							</span>
						</a>
						
						<a href="#" target="_blank">
							<img src="images/39.jpg" alt="View2" />
							<span>
								<b>View 2</b><br />
								Place some description here
							</span>
						</a>
						
						<a href="#" target="_blank">
							<img src="images/51.jpg" alt="Boat" />
							<span>
								<b>Boat</b><br />
								Place some description here
							</span>
						</a>
							
						<a href="#" target="_blank">
							<img src="images/46.jpg" alt="Sea Creature" />
							<span>
								<b>Sea Urchin</b><br />
								Place some description here
							</span>
						</a>
			
				</div>