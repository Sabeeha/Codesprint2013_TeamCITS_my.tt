<!DOCTYPE html>
<html lang="en">
<head>
<title>About | my.TT</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style_s.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>  
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>
<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "ur-2a253e3d-c198-9b8d-5f3-c893612cced1", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body id="page2">
<?php include 'fb_script.php';?>
<div class="extra">
	<div class="main">
<!-- header -->
		<header>
				<?php include 'fb_like.php';?>
			<nav>
				<?php include 'menu.php';?>
			</nav>
			<div class="text">
				<!-- <img src="images/text1.jpg" alt=""> -->
				<h2>About T&T</h2>
				<p>The islands of Trinidad and Tobago lie between 10 - 11 degrees latitude and 60 -61 degrees West longitude. The Republic of Trinidad and Tobago is the Caribbean's southernmost twin-island state. It lies approximately 18 km east of Venezuela on the South American continent; Trinidad and Tobago are the southernmost islands in the West Indies.</p>
				<!-- <a href="#" class="button">Read More</a> -->
			</div>
			<div class="img"><img src="images/tt.gif" alt=""></div>
		</header>
<!-- / header -->
<!-- content -->

		<section id="content">
		
		<!--
			<article class="col1">
				<h3>Hot Travel</h3>
				<div class="pad">
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/page1_img1.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Italy<br>Holidays</strong></p>
						<p class="pad_bot2">Lorem ipsum dolor sit amet, consect etuer adipiscing.</p>
						<a href="#" class="marker_1"></a>
					</div>
					<div class="wrapper under">
						<figure class="left marg_right1"><img src="images/page1_img2.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Philippines<br>Travel</strong></p>
						<p class="pad_bot2">Lorem ipsum dolor sit amet, consect etuer adipiscing.</p>
						<a href="#" class="marker_1"></a>
					</div>
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/page1_img3.jpg" alt=""></figure>
						<p class="pad_bot2"><strong>Cruise<br>Holidays</strong></p>
						<p class="pad_bot2">Lorem ipsum dolor sit amet, consect etuer adipiscing.</p>
						<a href="#" class="marker_1"></a>
					</div>
				</div>
        	</article>
			-->
			<article class="col2 pad_left1">
				<h2>The Twin Island Republic</h2>
				<div class="wrapper">
					<figure class="left marg_right1"><img src="images/page2_img1.jpg" alt=""></figure>
					<p>The average size of Trinidad is 4,827 km-squared with a channel of 35 km which separates the island at its north eastern point in Trinidad and the south eastern point in Tobago. The average area of Tobago is 303 km-squared, altogether total land mass encompasses an area of 512,835 hectares of land (Forest Policy in the Caribbean). </p>
				<p> Trinidad's northern Range is an extension of the South American Cordilleras, the highest peaks El Cerro del Aripo, is 940 m high. The centre of the island of Tobago is characterized by the Main Ridge, which is the oldest protected rain forest in the western hemisphere (17 April 1776) with the highest point being Centre Hill (573 m). The islands are only 33.6 km apart and comprise 55 123 km-squared with a coastline extending over 362 km. Physically, the islands are a combination of high ranges, flat land, swamps, and savannahs. These ecological niches are home to a wealth of diverse flora and fauna.</p>
				
				<p> The Pink and Yellow Poui, as well as the Immortelle, and Chaconia are vivid expressions of the country's highlights. The coral reefs around Tobago are an underwater exhibition for divers and the Speyside Reef boasts of the largest brain coral formation in the Caribbean. The native wildlife includes the Leatherback Turtle (Dermochelys conacea), Scarlet Ibis(Endocimus rubber), Pawi (Pipile pipile), Agouti (Dasyprocta leporina), Lappe (Agouti paca),Tatoo (Dasypus novemcintus), Manicou (Opossum), and several species of the Hummingbird. This does not include the multiplicity of mammals, birds, amphibians, fishes, and plants.</p>
				
				<p> The information was obtained from the <a href="http://cso.gov.tt">Central Statistical Office of Trinidad and Tobago.</a></p> 
				</div>
				<!--
				<div class="wrapper line1 marg_bot1">
					<ul class="list1 cols">
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Dignissimos ducimus qui blanditiis praesentium</a></li>
						<li><a href="#">Voluptatum deleniti atque corrupti quos dolores</a></li>
						<li><a href="#">Quas molestias excepturi sint occaecati</a></li>
					</ul>
					<ul class="list1 cols pad_left1">
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Dignissimos ducimus qui blanditiis praesentium</a></li>
						<li><a href="#">Voluptatum deleniti atque corrupti quos dolores</a></li>
						<li><a href="#">Quas molestias excepturi sint occaecati</a></li>
					</ul>
				</div>
				-->

       		</article>
		</section>
<!-- / content -->
	</div>
	<div class="block"></div>
</div>
<div class="body1">
<?php include 'social.php';?>
	<div class="main">
<!-- footer -->
		<footer>
			<?php include 'footer.php';?>		
		</footer>
<!-- / footer -->
	</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>