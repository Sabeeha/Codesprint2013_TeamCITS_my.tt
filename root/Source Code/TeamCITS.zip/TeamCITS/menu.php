<ul id="menu">
					<li><a href="index.php" class="nav1">Home</a></li>
					<li><a href="experience.php" class="nav3">Experience</a></li>
					<li class="end"><a href="visit.php" class="nav5">Our Visitors</a></li>
					<li><a href="plan.php" class="nav2">Plan Your Trip</a></li>
					<li><a href="about.php" class="nav4">About T&amp;T</a></li>
					
				</ul>