<div align="center">
<span class='st_facebook_vcount' displayText='Facebook'></span>
<span class='st_twitter_vcount' displayText='Tweet'></span>
<span class='st_linkedin_vcount' displayText='LinkedIn'></span>
<span class='st_googleplus_vcount' displayText='Google +'></span>
<span class='st_pinterest_vcount' displayText='Pinterest'></span>
</div>