<?php include '01/conn.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Experience: Places of Interest |  my.TT</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>  
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>

<!-- Ratings Jquery -->
<link rel='stylesheet' href='js/rating/jquery.rating.css'>
<script src="js/rating/jquery.form.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.MetaData.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.rating.js" type="text/javascript" charset="utf-8"></script>
<script src="js/rating/jquery.rating.pack.js" type="text/javascript" charset="utf-8"></script>

<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "ur-2a253e3d-c198-9b8d-5f3-c893612cced1", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body id="page3">
<?php include 'fb_script.php';?>
<div class="extra">
	<div class="main">
<!-- header -->
		<header>
		<?php include 'fb_like.php';?>
			<nav>
				<?php include 'menu.php';?>
			</nav>
			<div class="text">
				<!-- <img src="images/text1.jpg" alt=""> -->
				<h2>Places of Interest</h2>
				<p>Interested in History? Trinidad and Tobago's diverse cultural background is the reason why this multicultural society exists in unity today. The amazing highlights of our history are preserved so that you too can experience and understand our culture.</p>
				<!-- <a href="#" class="button">Read More</a> -->
			</div>
			 <div class="img"><img src="images/img2.jpg" alt=""></div> 
		</header>
<!-- / header -->
<!-- content -->
		<section id="content">
<?php include 'exp_menu.php';?>
			<article class="col2 pad_left1">
				<h2>The list:</h2>
				<?php include '01/query_placesinterest.php';?>
				<div class="wrapper">
					<article class="col3">
						<div class="wrapper">
							<!-- <figure class="left marg_right1"><img src="images/page3_img1.jpg" alt=""></figure> --> 
							<br>
							<p>Still have not found what you're looking for? Choose an option from the left to continue.</p>
				
					</article>
					<!-- 
					<article class="cols pad_left1">
						<ul class="list1">
							<li><a href="#">At vero eos et accusamus et</a></li>
							<li><a href="#">Gusto odio dignissimos ducimus </a></li>
							<li><a href="#">Blanditiis praesentium volupta</a></li>
							<li><a href="#">Tum deleniti atque corrupti</a></li>
							<li><a href="#">Quos dolores et quas molestias</a></li>
							<li><a href="#">Excepturi sint occaecati</a></li>
							<li><a href="#">Cupiditate non provident, simil</a></li>
							<li><a href="#">Ique sunt in culpa qui officia</a></li>
							<li><a href="#">Deserunt mollitia animi, id est</a></li>
							<li><a href="#">Laborum et dolorum fuga</a></li>
							<li><a href="#">Et harum quidem rerum facilis </a></li>
							<li><a href="#">Est et expedita distinctio</a></li>
							<li><a href="#">Nam libero tempore, cum soluta</a></li>
							<li><a href="#">Nobis est eligendi optio</a></li>
							<li><a href="#">Cumque nihil impedit quo</a></li>
							<li><a href="#">Minus id quod maxime placeat</a></li>
							<li><a href="#">Facere possimus, omnis</a></li>
							<li><a href="#">Voluptas assumenda est</a></li>
							<li><a href="#">Omnis dolor repellendus emp</a></li>
							<li><a href="#">Pribus autem quibusdam</a></li>
						</ul>
					</article>
					-->
				</div>
			</article>
		</section>
<!-- / content -->
	</div>
	<div class="block"></div>
</div>
<?php include 'social.php';?>
<div class="body1">
	<div class="main">
<!-- footer -->
		<footer>
			<?php include 'footer.php';?>			</footer>
<!-- / footer -->
	</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>