<!DOCTYPE html>
<html lang="en">
<head>
<title>Arrivals | my.TT</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style_vis.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>  
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>
<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/jquery.msCarousel-min.js"></script>
<link rel="stylesheet" type="text/css" href="css/mscarousel.css" />

<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "ur-2a253e3d-c198-9b8d-5f3-c893612cced1", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body id="page3">
<?php include 'fb_script.php';?>
	<div class="main">
<!-- header -->
		<header>
			<?php include 'fb_like.php';?>	
			<nav>
				<?php include 'menu.php';?>
			</nav>
				<a href="visit.php">Our Visitors</a> >> Arrivals
				<div align="center"><div class="text"><h2>Arrivals</h2></div></center>
				<article class="col1">
				
				<p>
				Select a Country for more in-depth  detail<br/>
				<a href="arrival_bar.php" target="_blank">Barbados Arrivals</a><br/>
				<a href="arrival_can.php" target="_blank">Canada Arrivals</a><br/>
				<a href="arrival_ger.php" target="_blank">Germany Arrivals</a><br/>
				<a href="arrival_gre.php" target="_blank">Grenada Arrivals</a><br/>
				<a href="arrival_guy.php" target="_blank">Guyana Arrivals</a><br/>
				<a href="arrival_uk.php" target="_blank">UK Arrivals</a><br/>
				<a href="arrival_usa.php" target="_blank">USA Arrivals</a><br/>
				<a href="arrival_ven.php" target="_blank">Venezuela</a><br/>
				</p>
				</article>
				<div align="center">
				<script type="text/javascript" src="http://public.tableausoftware.com/javascripts/api/viz_v1.js"></script><div class="tableauPlaceholder" style="width:954px; height:629px;"><noscript><a href="#"><img alt="Arrivals_Sheet " src="http:&#47;&#47;public.tableausoftware.com&#47;static&#47;images&#47;Ar&#47;Arrivals_0&#47;Arrivals_Sheet&#47;1_rss.png" style="border: none" /></a></noscript><object class="tableauViz" width="654" height="595" style="display:none;"><param name="host_url" value="http%3A%2F%2Fpublic.tableausoftware.com%2F" /><param name="site_root" value="" /><param name="name" value="Arrivals_0&#47;Arrivals_Sheet" /><param name="tabs" value="no" /><param name="toolbar" value="yes" /><param name="static_image" value="http:&#47;&#47;public.tableausoftware.com&#47;static&#47;images&#47;Ar&#47;Arrivals_0&#47;Arrivals_Sheet&#47;1.png" /><param name="animate_transition" value="yes" /><param name="display_static_image" value="yes" /><param name="display_spinner" value="yes" /><param name="display_overlay" value="yes" /><param name="display_count" value="yes" /></object></div><div style="width:654px;height:22px;padding:0px 10px 0px 0px;color:black;font:normal 8pt verdana,helvetica,arial,sans-serif;"><div style="float:right; padding-right:8px;"></div></div>
				</div>
				
						
					
				
			
		</header>
<!-- / header -->
<!-- content -->
		
<!-- / content -->
	</div>

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<?php include 'social.php';?>
<div class="body1">

	<div class="main">
<!-- footer -->
		<footer>
			<?php include 'footer.php';?>
		</footer>
<!-- / footer -->
	</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>

</body>
</html>