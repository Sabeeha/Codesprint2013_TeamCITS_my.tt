var d3_document = document,
    d3_window = window;
